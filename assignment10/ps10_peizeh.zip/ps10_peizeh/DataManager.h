//
//  DataManager.h
//  assignment10
//
//  Created by James Hong on 2022-11-23.
//
#include <stdio.h>
#include <vector>
#include <iostream>
#include <fstream>
#include "QuadraticFit.h"
#include "Line2D.h"

using namespace std;

class DM{
    
};
