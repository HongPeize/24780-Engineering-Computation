//
//  DataManager.cpp
//  assignment10
//
//  Created by James Hong on 2022-11-23.
//

#include "DataManager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "DrawingUtilNG.h"
#include "ysglfontdata.h"


using namespace std;

